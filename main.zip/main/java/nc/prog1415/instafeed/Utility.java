package nc.prog1415.instafeed;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

public class Utility {

    public static void AlertMessage(Context context, String title, String message, Intent intent)
    {

        if(context== null) return;

        //declare and set properties
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);

        dialog.setTitle((title.length()>0) ? title : "Alert");
        dialog.setMessage((message.length()>0)? message : "Alert Message");

        //dialog events
        dialog.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (intent != null)
                    context.startActivity(intent);
                else
                    dialogInterface.cancel();
            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        //show the dialog
        dialog.show();

    }
}
