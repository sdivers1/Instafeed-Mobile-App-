package nc.prog1415.instafeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {

    DatabaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        final EditText companyName = findViewById(R.id.txtRatingdisplay);
        final RatingBar ratingBar = (RatingBar) findViewById(R.id.companyRating);
        final EditText description = findViewById(R.id.txtDescription);
        final Button b = findViewById(R.id.btnSave);
        final TextView ratingResult = findViewById(R.id.txtRating);
        myDB = new DatabaseHelper(this);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                ratingResult.setText("Company Rating: " + String.valueOf(ratingBar.getRating()));

            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cName = companyName.getText().toString();
                String rResult = ratingResult.getText().toString();
                String desc = description.getText().toString();
                if(cName.length() != 0 && rResult.length() != 0 && desc.length() != 0) {
                    AddData(cName, rResult, desc);
                    Intent intent = new Intent(AddActivity.this, HomeActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(AddActivity.this, "Please enter feedback before you save it", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void AddData(String companyName, String ratingResults, String description)
    {
        boolean insertData = myDB.addData(companyName, ratingResults, description);

        if(insertData==true)
            Toast.makeText(AddActivity.this, "Feedback inserted successfully", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(AddActivity.this, "Sorry, something went wrong...", Toast.LENGTH_SHORT).show();
    }
}