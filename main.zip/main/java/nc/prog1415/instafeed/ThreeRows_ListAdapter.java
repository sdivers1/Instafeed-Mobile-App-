package nc.prog1415.instafeed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ThreeRows_ListAdapter extends ArrayAdapter<Feedback> {

    LayoutInflater inflater;
    ArrayList<Feedback> feedbacks;
    int mViewResourceId;

    public ThreeRows_ListAdapter(Context context, int textViewResourceId, ArrayList<Feedback> feedbacks) {
        super(context, textViewResourceId, feedbacks);
        this.feedbacks = feedbacks;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mViewResourceId = textViewResourceId;
    }

    public View getView(int position, View convertView, ViewGroup parents) {
        convertView = inflater.inflate(mViewResourceId,null);

        Feedback feedback = feedbacks.get(position);

        if(feedback != null) {
            TextView companyName = (TextView) convertView.findViewById(R.id.txtCompanyName);
            TextView companyRating = (TextView) convertView.findViewById(R.id.txtRatings);
            TextView feedDesc = (TextView) convertView.findViewById(R.id.txtDetails);

            if(companyName !=null)
                companyName.setText(feedback.getCompanyName());
            if(companyRating !=null)
                companyRating.setText(feedback.getCompanyRatings());
            if(companyRating !=null)
                feedDesc.setText(feedback.getFeedbackDetails());
        }
        return convertView;
    }
}
