package nc.prog1415.instafeed;

public class Feedback {

    String CompanyName;
    String CompanyRatings;
    String FeedbackDetails;

    public Feedback(String cName, String cRatings, String fDetails)
    {
        CompanyName = cName;
        CompanyRatings = cRatings;
        FeedbackDetails = fDetails;
    }

    public String getCompanyName()
    {
        return CompanyName;
    }

    public String getCompanyRatings()
    {
        return CompanyRatings;
    }

    public String getFeedbackDetails()
    {
        return FeedbackDetails;
    }
}
