package nc.prog1415.instafeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class HomeActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    ArrayList<Feedback> feedbackList;
    ListView listView;
    Feedback feedback;
    private LocationService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        service = new LocationService(this, LocationManager.GPS_PROVIDER);

        final ImageButton b = (ImageButton) this.findViewById(R.id.imgBtnAdd);
        myDB = new DatabaseHelper(this);
        feedbackList = new ArrayList<Feedback>();
        Cursor data = myDB.getListContents();
        int numRows = data.getCount();
        if(numRows == 0)
            Toast.makeText(HomeActivity.this, "There is nothing in this database!", Toast.LENGTH_SHORT).show();
        else {
            while (data.moveToNext()) {
                feedback = new Feedback(data.getString(1), data.getString(2), data.getString(3));
                feedbackList.add(feedback);
            }
            ThreeRows_ListAdapter adapter = new ThreeRows_ListAdapter(this, R.layout.list_adapter_view, feedbackList);
            listView = (ListView) findViewById(R.id.lvFoodCompanies);
            listView.setAdapter(adapter);

        }

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivity(intent);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        menu.add("Use current location");
        menu.add("About");
        menu.add("Additional Help");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getTitle().toString().equals("Use current location")) {
            Location location = service.getLocation();
            if (location != null || Geocoder.isPresent()) {
                Toast.makeText(HomeActivity.this, "Determining your location coordinates", Toast.LENGTH_SHORT).show();

                Geocoder coder = new Geocoder(HomeActivity.this);
                Location loc = service.getLastLocation();
                String output = "";
                if (loc != null) {
                    try {
                        Iterator<Address> addresses = coder.getFromLocation
                                (loc.getLatitude(), loc.getLongitude(), 3).iterator();
                        if (addresses.hasNext()) {
                            Address address = addresses.next();
                            String place = address.getLocality();

                            String country = address.getCountryName();
                            String street = address.getThoroughfare();
                            output = String.format("Showing results for : %s, %s, %s",
                                    street, place, country);
                        }
                        final TextView tv = HomeActivity.this.findViewById(R.id.txtShowAll);
                        tv.setText(output);

                    } catch (IOException ex) {
                    }
                } else {
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    Utility.AlertMessage(HomeActivity.this, "Give access to location", "To give access to location please click here", intent);
            }

            }
        }
        else if(item.getTitle().toString().equals("About"))
        {
            startActivity(new Intent(HomeActivity.this, AboutActivity.class));
        }
        else if(item.getTitle().toString().equals("Additional Help"))
        {
            startActivity(new Intent(HomeActivity.this, AdditionalHelpActivity.class));
        }
        return true;
    }
}