package nc.prog1415.instafeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //code for the timer
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //initializing a new intent
                Intent i = new Intent(MainActivity.this, HomeActivity.class);

                //start the activity
                startActivity(i);

                //finish the activity
                finish();
            }
        }, 2000);
    }
}