package nc.prog1415.instafeed;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class LocationService extends Service implements LocationListener {

    protected LocationManager manager;
    private Location location = null;
    private String provider = "";
    private Context context;
    private volatile boolean isEnabled = false;

    private final long UPDATE= 12000L;
    private final long DISTANCE = 10;

    public LocationService(Context context,String provider)
    {
        if(context == null)
            return;
        else
            this.context = context;

        if(provider.length()==0)
        {
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.NO_REQUIREMENT);
            criteria.setPowerRequirement(Criteria.NO_REQUIREMENT);
            this.provider = manager.getBestProvider(criteria,true);
        }
        else
            this.provider = provider;

        manager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
        if(manager.isProviderEnabled(this.provider))
            try {
                manager.requestLocationUpdates(this.provider, UPDATE, DISTANCE, this);
                this.isEnabled = true;
            }catch(SecurityException ex) {}
    }

    public Location getLocation()
    {
        return (this.isEnabled) ? this.location : null;
    }
    public Location getLastLocation()
    {
        Location location = null;
        try
        {
            location = manager.getLastKnownLocation(this.provider);
        }catch (SecurityException ex){}
        return location;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        this.location = location;
    }
    @Override
    public void onProviderDisabled(String provider) { this.isEnabled = false; }
    @Override
    public void onProviderEnabled(String provider) { }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) { }
}
